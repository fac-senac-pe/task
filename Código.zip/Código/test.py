{
  "nome": "Produto Exemplo",
  "valor": 99.99,
  "data": "2025-03-25"
}

{
  "nome": "Produto Exemplo",
  "valor": 99.99,
  "data": "2025-03-25",
  "uuid": "5c31ab2a-8fe3-4c9e-a0f3-cb8fc1a06f68"
}

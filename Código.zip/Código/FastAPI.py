from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, validator
from uuid import uuid4
from datetime import date

app = FastAPI()

# Definindo a estrutura do objeto Item
class Item(BaseModel):
    nome: str = Field(..., max_length=25)
    valor: float
    data: date

    # Validação personalizada para garantir que a data não seja superior à data atual
    @validator('data')
    def data_nao_pode_ser_no_futuro(cls, v):
        if v > date.today():
            raise ValueError("A data não pode ser superior à data atual.")
        return v

# Endpoint para processar o Item
@app.post("/processar_item/")
async def processar_item(item: Item):
    # Gerar UUID dinamicamente
    item_uuid = str(uuid4())

    # Retornar o item com o campo UUID adicional
    return {"nome": item.nome, "valor": item.valor, "data": item.data, "uuid": item_uuid}

